<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>No</th>
      <th>Ip Address</th>
      <th>Hits</th>
    </tr>
  </thead>
  <tbody id="bodytoday">
  </tbody>
</table>
<h3 id="jika24kosong" class="text-center"><h3>
