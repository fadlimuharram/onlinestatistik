<table class="table table-striped table-hover">
  <thead>
    <tr>
      <th>No</th>
      <th>Ip Address</th>
      <th>Hits</th>
    </tr>
  </thead>
  <tbody id="bodytotalpengunjung">
  </tbody>
</table>
<h3 id="jikaTotalkosong" class="text-center"><h3>
