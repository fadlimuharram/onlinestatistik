<?php
namespace App\Model;
use \Illuminate\Database\Capsule\Manager as Capsule;
use \Illuminate\Database\Eloquent\Model as Model;

class User extends Model{

  public $timestamps = false;

}

 ?>
